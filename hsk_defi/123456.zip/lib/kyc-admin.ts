import { createPublicClient, http, parseAbi } from "viem"
import { hashkeyChainTestnet } from "./chains"
import { getUsersCollection } from "./couchbase-util"
// KYC 인증 취소 함수를 wagmi의 useWriteContract hook을 사용하도록 수정
import { writeContract, getAccount } from "@wagmi/core"
import { config } from "@/wagmi-config"

// KYC Registry 컨트랙트 주소 (실제 배포된 주소로 변경해야 함)
const KYC_REGISTRY_ADDRESS = "0x488a60cFcb23Aeb103bA8E2E9C970F8266168D1E" as const

// KYC Registry 컨트랙트 ABI - 실제 배포된 컨트랙트에 맞게 수정
const kycRegistryAbi = parseAbi([
  "function isVerified(address user) view returns (bool)",
  "function check(address user) view returns (bool)",
  "function revoke(address user)",
  "function admin() view returns (address)",
])

// 블록체인 클라이언트 생성
const publicClient = createPublicClient({
  chain: hashkeyChainTestnet,
  transport: http(),
})

/**
 * 대기 중인 KYC 사용자 목록 가져오기
 * @returns 대기 중인 KYC 사용자 목록
 */
export async function getPendingKYCUsers() {
  try {
    // 데이터베이스에서 모든 사용자 가져오기
    const usersCollection = await getUsersCollection()
    const query = `
      SELECT META().id as address, * 
      FROM \`borrow\` 
      WHERE status = "pending"
    `
    const result = await usersCollection.query(query)

    return result.rows
  } catch (error) {
    console.error("대기 중인 KYC 사용자 목록 가져오기 실패:", error)
    throw error
  }
}

/**
 * 인증된 KYC 사용자 목록 가져오기
 * @returns 인증된 KYC 사용자 목록
 */
export async function getVerifiedKYCUsers() {
  try {
    // 데이터베이스에서 인증된 사용자 가져오기
    const usersCollection = await getUsersCollection()
    const query = `
      SELECT META().id as address, * 
      FROM \`borrow\` 
      WHERE status = "success"
    `
    const result = await usersCollection.query(query)

    return result.rows
  } catch (error) {
    console.error("인증된 KYC 사용자 목록 가져오기 실패:", error)
    throw error
  }
}

/**
 * KYC 인증 취소
 * @param userAddress 취소할 사용자 주소
 */
export async function revokeKYC(userAddress: string) {
  try {
    // 현재 연결된 계정 가져오기
    const account = getAccount(config)

    if (!account || !account.address) {
      throw new Error("연결된 지갑이 없습니다.")
    }

    // wagmi의 writeContract 함수 사용 - account 속성 추가
    const result = await writeContract(config, {
      address: KYC_REGISTRY_ADDRESS,
      abi: kycRegistryAbi,
      functionName: "revoke",
      args: [userAddress as `0x${string}`],
      account: account.address, // 계정 주소 추가
    })

    console.log("KYC 인증 취소 트랜잭션:", result)

    // 2. 데이터베이스 상태 업데이트
    const usersCollection = await getUsersCollection()
    const user = await usersCollection.get(userAddress)

    if (user) {
      user.content.status = "revoked"
      await usersCollection.replace(userAddress, user.content)
    }

    return result
  } catch (error) {
    console.error("KYC 인증 취소 실패:", error)
    throw error
  }
}

/**
 * 사용자의 KYC 상태 확인
 * @param userAddress 확인할 사용자 주소
 * @returns KYC 인증 여부
 */
export async function checkKYCStatus(userAddress: string): Promise<boolean> {
  try {
    return (await publicClient.readContract({
      address: KYC_REGISTRY_ADDRESS,
      abi: kycRegistryAbi,
      functionName: "check",
      args: [userAddress as `0x${string}`],
    })) as boolean
  } catch (error) {
    console.error("KYC 상태 확인 실패:", error)
    return false
  }
}

/**
 * 데이터베이스에서 사용자 KYC 상태 업데이트
 * @param userAddress 사용자 주소
 * @param status 새로운 상태
 */
export async function updateUserKYCStatus(userAddress: string, status: string) {
  try {
    const usersCollection = await getUsersCollection()

    try {
      const user = await usersCollection.get(userAddress)
      user.content.status = status
      await usersCollection.replace(userAddress, user.content)
      return true
    } catch (err: any) {
      // 타입을 any로 명시적으로 지정
      // 사용자가 없는 경우 새로 생성
      if (err.code === 13) {
        await usersCollection.insert(userAddress, { status })
        return true
      }
      throw err
    }
  } catch (error) {
    console.error("사용자 KYC 상태 업데이트 실패:", error)
    throw error
  }
}

