import { createPublicClient, http, parseAbi } from "viem"
import { hashkeyChainTestnet } from "./chains"

// KYC Registry 컨트랙트 주소 (실제 배포된 주소로 변경해야 함)
const KYC_REGISTRY_ADDRESS = "0x488a60cFcb23Aeb103bA8E2E9C970F8266168D1E" as const

// KYC Registry 컨트랙트 ABI - 실제 배포된 컨트랙트에 맞게 수정
const kycRegistryAbi = parseAbi([
  "function isVerified(address user) view returns (bool)",
  "function check(address user) view returns (bool)",
])

// 블록체인 클라이언트 생성
const publicClient = createPublicClient({
  chain: hashkeyChainTestnet,
  transport: http(),
})

// KYC 상태 타입 정의
export type KYCStatus = "success" | "pending" | "rejected" | "not_found" | "error"

/**
 * 사용자의 KYC 상태를 블록체인에서 확인하는 함수
 * @param address 사용자 지갑 주소
 * @returns KYC 상태 ("success", "pending", "rejected", "not_found", "error" 중 하나)
 */
export async function checkKYCStatus(address: string): Promise<KYCStatus> {
  try {
    // 블록체인에서 KYC 인증 여부 확인
    const isVerified = await publicClient.readContract({
      address: KYC_REGISTRY_ADDRESS,
      abi: kycRegistryAbi,
      functionName: "check",
      args: [address as `0x${string}`],
    })

    if (isVerified) {
      return "success"
    }

    // 블록체인에서 인증되지 않은 경우, 데이터베이스에서 상태 확인
    try {
      const { getWalletStatus } = await import("./wallet-db")
      const dbStatus = await getWalletStatus(address)

      // wallet-db.ts의 getWalletStatus 함수가 반환하는 타입과 일치시키기
      if (dbStatus === "pending") {
        return "pending"
      } else if (dbStatus === "rejected") {
        return "rejected"
      }

      return "not_found"
    } catch (dbError) {
      console.error("데이터베이스 상태 확인 실패:", dbError)
      return "not_found"
    }
  } catch (error) {
    console.error("KYC 상태 확인 실패:", error)
    return "error"
  }
}

/**
 * 사용자의 KYC 인증 여부만 확인하는 함수
 * @param address 사용자 지갑 주소
 * @returns KYC 인증 여부 (true/false)
 */
export async function isKYCVerified(address: string): Promise<boolean> {
  try {
    return (await publicClient.readContract({
      address: KYC_REGISTRY_ADDRESS,
      abi: kycRegistryAbi,
      functionName: "check",
      args: [address as `0x${string}`],
    })) as boolean
  } catch (error) {
    console.error("KYC 인증 확인 실패:", error)
    return false
  }
}

